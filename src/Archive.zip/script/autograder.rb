# Runs a `.travis.yml` file
# stuffs everything in STDOUT visiable to students.

require 'yaml'
require 'open3'
require 'json'

RESULTS = { output: '', stdout_visibility: 'visible' }
RESULTS_FILEPATH = 'results/results.json'

stdout, stderr, status = Open3.capture3("ls")

RESULTS[:output] << "STDOUT LS:\n\n#{stdout}\n#{'=' * 20}\n\n"
RESULTS[:output] << "STDERR LS:\n\n#{stderr}\n#{'=' * 20}\n\n"
RESULTS[:output] << "STATUS LS:\n\n#{status}\n#{'=' * 20}\n\n"

File.open(RESULTS_FILEPATH,"w") do |f|
  f.write(RESULTS.to_json)
end

def default_rails_steps
  [
    'bundle install',
    'yarn install',
    'export RAILS_ENV=test'
    'bundle exec rake db:setup',
    'bundle exec rspec spec/',
    'bundle exec cucumber'
  ]
end

def exec_command(command)

end

def travis_file_present?

end

def exec_travis_steps

end
